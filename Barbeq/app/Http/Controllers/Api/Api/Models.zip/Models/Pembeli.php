<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pembeli extends Model
{
    use HasFactory;
    protected $guarded = ['id'];
    protected $fillable = [
        'kode',
        'nama_pembeli',
        'email',
        'password',
        'no_tlp',
        'alamat_pembeli',
        'gambar',

    ];

    public function scopeFilter($query, array $filters){

        $query->when($filters['search'] ?? false,function($query,$search){
            return
            $query->where('id','like','%'. $search.'%')
            ->orWhere('nama_pembeli','like','%'. $search.'%');
        });


        $query->when(
            //author berasal dari url yang di kirim
            $filters['author'] ?? false,
            fn ($query,$author) =>
            //author berasal dari relasi method public function author()
            $query->whereHas('author',
                fn($query) =>
                $query->where('username', $author)
            )

        );

    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function author()
    {
        //Post ke Categories Relasi satu ke satu
        return $this->belongsTo(User::class,'user_id');
    }

    public function getRouteKeyName()
    {
        return 'id';
    }


}
