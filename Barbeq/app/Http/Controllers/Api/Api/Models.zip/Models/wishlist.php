<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class wishlist extends Model
{
    use HasFactory;
    protected $guarded = ['id'];
    protected $table = "wishlists";
    protected $fillable = [

        'nama_product',
        'harga',
        'gambar',
        'kategori'

    ];
    public function kategori()
    {
        //Post ke Categories Relasi satu ke satu
        return $this->belongsTo(kategori::class);
    }
}
